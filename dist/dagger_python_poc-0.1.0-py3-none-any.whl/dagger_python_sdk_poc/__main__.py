#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Module documentation
"""


def main():
    """The main script entrypoint"""
    print("Your codes goes here!")


if __name__ == '__main__':
    main()
