# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['dagger_python_sdk_poc']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'dagger-python-poc',
    'version': '0.1.0',
    'description': 'A quick PoC about dagger python SDK',
    'long_description': '# Dagger python SDK Proof Of Concept\n\nThe idea is to give a try to [this](https://docs.dagger.io/sdk/python) amazing SDK with a more or less\nreal python project that uses:\n  * [Poetry](https://python-poetry.org/) as the build and package tool\n  * Using the `src` pattern, which is not used by default in poetry projects\n  * Using [pytest](https://pytest.org/) as Test frameworkhttps://docs.dagger.io/sdk/python\n',
    'author': 'Javier Juarez',
    'author_email': 'jj@chainedto.cloud',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
