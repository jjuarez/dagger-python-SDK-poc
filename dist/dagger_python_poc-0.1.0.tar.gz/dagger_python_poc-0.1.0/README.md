# Dagger python SDK Proof Of Concept

The idea is to give a try to [this](https://docs.dagger.io/sdk/python) amazing SDK with a more or less
real python project that uses:
  * [Poetry](https://python-poetry.org/) as the build and package tool
  * Using the `src` pattern, which is not used by default in poetry projects
  * Using [pytest](https://pytest.org/) as Test frameworkhttps://docs.dagger.io/sdk/python
